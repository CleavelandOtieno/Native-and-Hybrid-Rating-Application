package ke.ac.gre.example.nativeapp_cw_cleaveland;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;


public class irateActivity extends AppCompatActivity {

    private DatabaseAssistant dbHHelper;
    private String[] restaurantType = {"Fast Food", "Fast Casual", "Fine Dining", "Grill", "Sea Food", "Cafeteria", "Pop-Up Restaurant", "Coffee House" };
    TextView serviceRatingScale;
    TextView cleanlinessRatingScale;
    TextView foodRatingScale;
    AwesomeValidation irateValidation;
    ImageView ImagePlatform;
    Button openCam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rateinput);
        DatePicker DP = findViewById(R.id.DatePickerDOV);
        serviceRatingScale = (TextView) findViewById(R.id.serviceRate);
        cleanlinessRatingScale = (TextView) findViewById(R.id.cleanRate);
        foodRatingScale = (TextView) findViewById(R.id.foodRate);
        DP.init(2010, 1, 1, null);

        RatingBar serviceInput = findViewById(R.id.serviceRating);
        serviceInput.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar servicerating, float v, boolean b) {
                serviceRatingScale.setText(String.valueOf(v));
                switch ((int) servicerating.getRating()){
                    case 1:
                        serviceRatingScale.setText("Need to improve");
                        break;
                    case 2:
                        serviceRatingScale.setText("OKAY");
                        break;
                    case 3:
                        serviceRatingScale.setText("Good");
                        break;
                    case 4:
                        serviceRatingScale.setText("Perfect");
                        break;
                    case 5:
                        serviceRatingScale.setText("Excellent");
                        break;
                    default:
                        serviceRatingScale.setText("");

                }
            }
        });
        RatingBar cleanInput = findViewById(R.id.cleanRating);
        cleanInput.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar cleanratingBar, float v, boolean b) {
                cleanlinessRatingScale.setText(String.valueOf(v));
                switch ((int) cleanratingBar.getRating()){
                    case 1:
                        cleanlinessRatingScale.setText("Need to improve");
                        break;
                    case 2:
                        cleanlinessRatingScale.setText("OKAY");
                        break;
                    case 3:
                        cleanlinessRatingScale.setText("Good");
                        break;
                    case 4:
                        cleanlinessRatingScale.setText("Perfect");
                        break;
                    case 5:
                        cleanlinessRatingScale.setText("Excellent");
                        break;
                    default:
                        cleanlinessRatingScale.setText("");
                }
            }
        });
        RatingBar foodInput = findViewById(R.id.foodRating);
        foodInput.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar foodratingBar, float v, boolean b) {
                foodRatingScale.setText(String.valueOf(v));
                switch ((int) foodratingBar.getRating()){
                    case 1:
                        foodRatingScale.setText("Need to improve");
                        break;
                    case 2:
                        foodRatingScale.setText("OKAY");
                        break;
                    case 3:
                        foodRatingScale.setText("Good");
                        break;
                    case 4:
                        foodRatingScale.setText("Perfect");
                        break;
                    case 5:
                        foodRatingScale.setText("Excellent");
                        break;
                    default:
                        foodRatingScale.setText("");
                }
            }
        });

        Button buttonNext = findViewById(R.id.ButtonNext);
        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNextAlert();
            }
        });
        Spinner typeSP= findViewById(R.id.typeSpinner);
        dbHHelper = new DatabaseAssistant(this); //a gateway to access the database
        typeSP.setAdapter(new ArrayAdapter<String>(this, R.layout.spinner_listandrecords, restaurantType));
        irateValidation = new AwesomeValidation(ValidationStyle.BASIC);
         irateValidation.addValidation(this,R.id.EditrestaurantName, RegexTemplate.NOT_EMPTY,R.string.invalid_restaurantName);
        irateValidation.addValidation(this,R.id.typeSpinner, RegexTemplate.NOT_EMPTY,R.string.invalid_restaurantType);
        irateValidation.addValidation(this,R.id.DatePickerDOV, RegexTemplate.NOT_EMPTY,R.string.invalid_DOV);
        irateValidation.addValidation(this,R.id.TimePickerTOV, RegexTemplate.NOT_EMPTY,R.string.invalid_TOV);
        irateValidation.addValidation(this,R.id.EditMealPrice, RegexTemplate.NOT_EMPTY,R.string.invalid_mealPrice);
        irateValidation.addValidation(this,R.id.EditreporterName, RegexTemplate.NOT_EMPTY,R.string.invalid_reporterName);
        if(serviceInput.getRating() == 0.0){
            Toast.makeText(this,"Please enter a Rating", Toast.LENGTH_SHORT).show();
        }
        if(cleanInput.getRating() == 0.0){
            Toast.makeText(this,"Please enter a Rating", Toast.LENGTH_SHORT).show();
        }
        if(foodInput.getRating() == 0.0){
            Toast.makeText(this,"Please enter a Rating", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayNextAlert() {
        EditText restaurantNameInput = findViewById(R.id.EditrestaurantName);
        Spinner typeSP= findViewById(R.id.typeSpinner);
        DatePicker DOVInput = findViewById(R.id.DatePickerDOV);
        TimePicker TPInput = findViewById(R.id.TimePickerTOV);
        EditText mealPriceInput = findViewById(R.id.EditMealPrice);
        serviceRatingScale = (TextView) findViewById(R.id.serviceRate);
        cleanlinessRatingScale = (TextView) findViewById(R.id.cleanRate);
        foodRatingScale = (TextView) findViewById(R.id.foodRate);

        EditText notesInput = findViewById(R.id.EditNotes);
        EditText reporterInput = findViewById(R.id.EditreporterName);
        CheckBox agreeTermsInput = findViewById(R.id.chkAgreeTerms);


        if(irateValidation.validate()) {
            final String strRestaurantName = restaurantNameInput.getText().toString();
            int row = typeSP.getSelectedItemPosition();
            final String strRestaurantType = restaurantType[row];

            final String strDOV = DOVInput.getDayOfMonth() + "/" + (DOVInput.getMonth() + 1) + "/" + DOVInput.getYear();

            final Integer strTOV = TPInput.getCurrentHour() + TPInput.getCurrentMinute();
            final String strMealPrice = mealPriceInput.getText().toString();
            final String strService = serviceRatingScale.getText().toString();
            final String strClean = cleanlinessRatingScale.getText().toString();
            final String strFood = foodRatingScale.getText().toString();
            final String strNotes = notesInput.getText().toString();
            final String strReporter = reporterInput.getText().toString();


            if (agreeTermsInput.isChecked()) {

                new AlertDialog.Builder(this).setTitle("Ratings Completed").setMessage("Restaurant name:" + strRestaurantName + "\n" + "Restaurant type:" + strRestaurantType
                        + "\n" + "Date of visitation:" + strDOV
                        + "\n" + "Time of visitation:" + strTOV + "\n" + "Average meal price:" + strMealPrice  + "\n" + "Your Rating" + "\n" + "Services ratings:" + strService
                        + "\n" + " Cleanliness ratings:" + strClean + "\n" + "Food Quality ratings:" + strFood
                        + "\n" + "Notes taken:" + strNotes + "\n" + "Reporter's name:" + strReporter)
                        .setNeutralButton("Back", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                        .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                saveUserRatings(strRestaurantName,strRestaurantType, strDOV, strTOV, strMealPrice,
                                        strService, strClean, strFood, strNotes, strReporter);
                            }
                        }).show();

            } else {
                popupToast("Sorry!!!!Please Check to agree on the above ratings then Proceed.........");
                return;
            }
            Toast.makeText(getApplicationContext(),"Form Complete",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(),"Form incomplete",Toast.LENGTH_SHORT).show();
        }


    }

    protected void saveUserRatings(String strRestaurantName, String strRestaurantType, String strDOV, Integer strTOV,
                                   String strMealPrice, String strService, String strClean, String strFood, String strNotes, String strReporter) {
        try {
            //insert User details
            dbHHelper.insertUserRatings(strRestaurantName,strRestaurantType ,strDOV, strTOV, strMealPrice, strService, strClean , strFood, strNotes, strReporter);
            long TotalRecords = dbHHelper.getNumberOfRecords();
            //confirm details are saved
            new AlertDialog.Builder(irateActivity.this)
                    .setTitle("***Your Ratings have been Saved***" + TotalRecords + "records have been stored")
                    .setNeutralButton("Next", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    }).show();
        } catch (SQLiteException sqle) {
            sqle.printStackTrace();
            android.util.Log.w(this.getClass().getName(), "***Cannot Save Your Ratings***");
            new AlertDialog.Builder(irateActivity.this)
                    .setTitle("***Cannot Save***")
                    .setNeutralButton("Next", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    }).show();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_commands,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem mitem){
        switch (mitem.getItemId()){
            case R.id.nav_photos:
                displayNextAlert();
                return true;
            case R.id.nav_exit:
                popupToast("You want to exit?Just start a new Application!!!!!");
                return true;
            default:
                return super.onOptionsItemSelected(mitem);
        }
    }



    public void popupToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    public void openPhotoDialog(){
        Custom_TakePhoto CTP = new Custom_TakePhoto();
        CTP.show(getSupportFragmentManager(),"Take Pictures");
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.READ_EXTERNAL_STORAGE} ,0);
        }

    }


}
