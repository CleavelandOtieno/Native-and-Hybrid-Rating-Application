package ke.ac.gre.example.nativeapp_cw_cleaveland;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.core.content.ContextCompat;

public class Custom_TakePhoto extends AppCompatDialogFragment {
    final int PHOTO_RESULT =1;
    private Uri mLastPhotoURI =null;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder createPhotoUI = new AlertDialog.Builder(getContext());
        LayoutInflater inflatePhotoUI = getActivity().getLayoutInflater();
        View vv = inflatePhotoUI.inflate(R.layout.activity_takephoto,null);
        createPhotoUI.setView(vv) .setTitle("Take a Photo")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("Capture", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        return createPhotoUI.create();
    }



    }

