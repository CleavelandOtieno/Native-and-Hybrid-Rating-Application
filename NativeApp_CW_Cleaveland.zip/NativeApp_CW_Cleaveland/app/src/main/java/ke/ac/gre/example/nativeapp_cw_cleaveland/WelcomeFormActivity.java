package ke.ac.gre.example.nativeapp_cw_cleaveland;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeFormActivity  extends AppCompatActivity {
    private DatabaseAssistant dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        Button btnEnter = findViewById(R.id.buttonEnter);
        Button btnList = findViewById(R.id.buttonList);
        Button btnDelete = findViewById(R.id.buttonDelete);
        btnEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayEnterDataScreen();
            }
        });
        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayListScreen();
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteRecords();
            }
        });

        dbHelper = new DatabaseAssistant(this);
    }

    private void displayListScreen() {
        startActivity(new Intent(this, rateListActivity.class));
    }

    private void displayEnterDataScreen() {
        startActivity(new Intent(this, irateActivity.class));
    }

    private void deleteRecords(){
        //display dialog for delete of record
        new AlertDialog.Builder(this)
                .setMessage("**Do you want to delete all the records?**")
                .setNegativeButton("No",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                .setPositiveButton("Yes!",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dbHelper.deleteAllRecords();
                                popupToast("All the record have been deleted");
                            }
                        }).show();
    }


    private void popupToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}