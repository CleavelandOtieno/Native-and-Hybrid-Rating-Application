package ke.ac.gre.example.nativeapp_cw_cleaveland;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.RatingBar;

public class DatabaseAssistant extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "User_Ratings";
    private SQLiteDatabase database;

    public DatabaseAssistant(Context context) {
        super(context, DATABASE_NAME, null, 1); //DB version
        database = getWritableDatabase(); // getting the reference to the DB that is going to be used to insert details
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE UserRatings (_ID INTEGER PRIMARY KEY AUTOINCREMENT, NameofRestaurant TEXT, TypeofRestaurant TEXT, DateofVisit TEXT, TimeofVisit INTEGER, AverageMealPrice TEXT, RatingforService TEXT, RatingforCleanliness TEXT, QualityofFood TEXT, NotesTaken TEXT, NameofReporter TEXT)");
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //loosing the older details and be replaced with the new ones happening in the logcat
        android.util.Log.w(this.getClass().getName(), DATABASE_NAME + "database upgraded to version" + newVersion + "old data will be lost");
        db.execSQL("DROP TABLE IF EXISTS UserRatings");
        onCreate(db);
    }

    public long insertUserRatings(String strRestaurantName, String strRestaurantType, String strDOV, Integer strTOV, String strMealPrice, String strService, String strClean, String strFood, String strNotes, String strReporter) {
        ContentValues rowValues = new ContentValues();
        rowValues.put("NameofRestaurant", strRestaurantName);
        rowValues.put("TypeofRestaurant", strRestaurantType);
        rowValues.put("DateofVisit", strDOV);
        rowValues.put("TimeofVisit", strTOV);
        rowValues.put("AverageMealPrice", strMealPrice);
        rowValues.put("RatingforService", strService);
        rowValues.put("RatingforCleanliness", strClean);
        rowValues.put("QualityofFood", strFood);
        rowValues.put("NotesTaken", strNotes);
        rowValues.put("NameofReporter", strReporter);

        return database.insertOrThrow("UserRatings", null, rowValues);
    }

    public long getNumberOfRecords() {
        Cursor CC = database.query("UserRatings", null, null, null, null, null, null);
        return CC.getCount();
    }
    public Cursor getAllRecords()
    {
        return database.query("UserRatings", null,null, null,null,null,"NameofRestaurant");
    }
    public void deleteAllRecords()
    {
        database.delete("UserRatings",null,null);
    }
}