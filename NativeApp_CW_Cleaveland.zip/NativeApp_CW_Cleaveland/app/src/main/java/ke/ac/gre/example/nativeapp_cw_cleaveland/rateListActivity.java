package ke.ac.gre.example.nativeapp_cw_cleaveland;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.CursorAdapter;
import android.widget.SimpleCursorAdapter;

public class rateListActivity extends ListActivity {
    private DatabaseAssistant dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listrecordlayout);
        dbHelper = new DatabaseAssistant(this);
        displayData();
    }
    private void displayData()
    {
        Cursor result = dbHelper.getAllRecords();
        String[] columnNames = {"NameofRestaurant", "TypeofRestaurant", "DateofVisit",
                "TimeofVisit","AverageMealPrice", "RatingforService", "RatingforCleanliness ", "QualityofFood ","NotesTaken", "NameofReporter"};
        int[] displayNames = {R.id.EditrestaurantName, R.id.typeSpinner,R.id.DatePickerDOV, R.id.TimePickerTOV,
                R.id.EditMealPrice,R.id.serviceRate,R.id.cleanRate,R.id.foodRate,
                R.id.EditNotes,R.id.EditreporterName};
        SimpleCursorAdapter records = new SimpleCursorAdapter(this, R.layout.list_ratingrecord, result, columnNames, displayNames, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        setListAdapter(records);
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_commands,menu);
        return true;
    }
    //process the selection from menu
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.searchRestaurant:
                super.onBackPressed(); //simulate back button
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
